#!/usr/bin/env python3
"""
DeployXCloud Shield — Key Generator
=====================================
Run this ONCE on the VPS where you want to apply DDoS protection.
It generates a secure random key and saves it to shield_key.txt.

Usage:
    python3 gen_key.py

Then:
  1. Copy the key into ddos_protection.py → DDOS_APPLY_KEY = "..."
  2. Copy the same key into your dashboard .env → DDOS_APPLY_KEY=...
  3. Restart the shield:  pm2 restart ddos
"""

import secrets
import os
import datetime

KEY_FILE = "shield_key.txt"

def generate_key() -> str:
    return "dxs_" + secrets.token_hex(32)

def main():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE) as f:
            existing = f.read().strip()
        print(f"\n⚠️  A key already exists in {KEY_FILE}:")
        print(f"   {existing}")
        answer = input("\n   Generate a NEW key? This will invalidate the old one. (yes/no): ").strip().lower()
        if answer != "yes":
            print("   Keeping existing key. Bye!")
            return
        print()

    key = generate_key()
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(KEY_FILE, "w") as f:
        f.write(key)

    separator = "=" * 60
    print(f"\n{separator}")
    print("   DeployXCloud Shield — Key Generated Successfully")
    print(separator)
    print(f"\n   KEY:  {key}")
    print(f"\n   Saved to: {KEY_FILE}")
    print(f"   Generated: {timestamp}")
    print(f"\n{separator}")
    print("\n   NEXT STEPS:")
    print(f"\n   1. Open ddos_protection.py and set:")
    print(f'      DDOS_APPLY_KEY = "{key}"')
    print(f"\n   2. In your dashboard VPS .env file, set:")
    print(f"      DDOS_APPLY_KEY={key}")
    print(f"\n   3. Restart the shield:")
    print(f"      pm2 restart ddos")
    print(f"\n{separator}\n")

if __name__ == "__main__":
    main()
