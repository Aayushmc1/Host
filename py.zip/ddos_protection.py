#!/usr/bin/env python3
"""
DeployXCloud Shield — DDoS & Bot Protection
============================================
Run this on the VPS where your Pterodactyl panel is hosted (port 80).
The shield listens on a port in front of Pterodactyl and reports all
attack events in real-time to your DeployXCloud Shield dashboard.

SETUP STEPS:
  1. Generate a key on this VPS:     python3 gen_key.py
  2. Fill in MONGODB_URL below       (your MongoDB Atlas or local URL)
  3. Fill in DDOS_APPLY_KEY below    (the key you generated with gen_key.py)
  4. Fill in DASHBOARD_URL below     (URL of your dashboard VPS, e.g. http://1.2.3.4:3000)
  5. Start with PM2:                 pm2 start "python3 ddos_protection.py" --name ddos

HOW IT WORKS:
  Browser/attacker → Shield (this script) → Pterodactyl Panel (port 80)
  Shield also reports every blocked request to your dashboard in real-time.
"""

# ============================================================
#   CONFIGURE THESE VALUES BEFORE STARTING
# ============================================================

MONGODB_URL    = ""   # e.g. mongodb+srv://user:pass@cluster.mongodb.net/shield
DDOS_APPLY_KEY = ""   # Key from gen_key.py — must match the one in your dashboard .env
DASHBOARD_URL  = ""   # e.g. http://your-dashboard-vps:3000/api  (no trailing slash)

# ============================================================
#   OPTIONAL — ADVANCED SETTINGS (you can leave these as-is)
# ============================================================

SHIELD_PORT      = 7070            # Port this shield listens on (put Nginx/Caddy in front)
BACKEND_URL      = "http://127.0.0.1:80"   # Your Pterodactyl panel address
MANAGEMENT_PORT  = 9090            # Local management API port (stats, ban, unban)
LOG_FILE         = "ddos_shield.log"
REPORT_ALLOWED   = False           # Set True to also report clean requests to dashboard
USE_IPTABLES     = False           # Set True to ban at kernel level (requires root)

RATE_LIMIT_REQUESTS   = 100   # Max requests per window per IP
RATE_LIMIT_WINDOW     = 60    # Rate limit window in seconds
BURST_LIMIT           = 20    # Max requests in the last 1 second (burst)
BAN_AFTER_VIOLATIONS  = 5     # Violations before temp-ban
TEMP_BAN_DURATION     = 300   # Temp-ban duration in seconds (5 min)
PERM_BAN_AFTER        = 3     # Temp-bans before permanent ban
MAX_CONNECTIONS_PER_IP = 50
MAX_PAYLOAD_BYTES      = 10_485_760  # 10 MB

WHITELIST = ["127.0.0.1", "::1"]  # IPs that are never blocked
BLACKLIST = []                     # IPs that are always blocked on startup

# ============================================================
#   DO NOT EDIT BELOW THIS LINE
# ============================================================

import collections
import json
import logging
import os
import queue
import re
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Dict, Optional, Tuple


def setup_logger(log_file: str) -> logging.Logger:
    logger = logging.getLogger("deployxcloud_shield")
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    if log_file:
        try:
            fh = logging.FileHandler(log_file)
            fh.setFormatter(fmt)
            logger.addHandler(fh)
        except Exception:
            pass
    return logger


class DashboardReporter:
    def __init__(self, dashboard_url: str, shield_key: str, logger: logging.Logger):
        self.url = dashboard_url.rstrip("/")
        self.key = shield_key
        self.logger = logger
        self._q: queue.Queue = queue.Queue(maxsize=5000)
        self._enabled = bool(dashboard_url and shield_key)
        if self._enabled:
            threading.Thread(target=self._worker, daemon=True).start()
            logger.info("Dashboard reporting enabled → %s", self.url)
        else:
            logger.warning(
                "Dashboard reporting DISABLED. Fill in DASHBOARD_URL and DDOS_APPLY_KEY."
            )

    def report(self, ip, path, method, reason, action, ua=""):
        if not self._enabled:
            return
        try:
            self._q.put_nowait({
                "ip": ip, "path": path[:500], "method": method,
                "reason": reason[:200], "action": action,
                "userAgent": ua[:300], "shieldKey": self.key,
            })
        except queue.Full:
            pass

    def _worker(self):
        while True:
            payload = self._q.get()
            self._send(payload)
            self._q.task_done()

    def _send(self, payload: dict):
        try:
            body = json.dumps(payload).encode()
            req = urllib.request.Request(
                f"{self.url}/shield/report",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=5):
                pass
        except Exception:
            pass


BLOCKED_UA_PATTERNS = [
    r"python-requests", r"curl/", r"wget/", r"scrapy", r"nikto", r"sqlmap",
    r"nmap", r"masscan", r"zgrab", r"go-http-client", r"libwww-perl",
    r"perl\s", r"java/", r"jakarta", r"ahrefsbot", r"semrushbot",
    r"dotbot", r"mj12bot", r"blexbot", r"petalbot", r"bytespider",
    r"gptbot", r"ccbot", r"claudebot", r"anthropic-ai",
]

BLOCKED_PATH_PATTERNS = [
    r"\.php$", r"\.(env|git|svn|htaccess|htpasswd|DS_Store)$",
    r"wp-admin", r"wp-login", r"xmlrpc", r"/etc/passwd",
    r"select\s+.*\s+from", r"union\s+select", r"<script",
    r"\.\./", r"cmd\.exe", r"/bin/sh", r"/bin/bash",
    r"eval\(", r"base64_decode",
]

ALLOWED_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]


class DeployXCloudShield:
    def __init__(self):
        self.logger = setup_logger(LOG_FILE)
        self.reporter = DashboardReporter(DASHBOARD_URL, DDOS_APPLY_KEY, self.logger)
        self._lock = threading.Lock()
        self._req_log: Dict[str, collections.deque] = collections.defaultdict(collections.deque)
        self._burst_log: Dict[str, collections.deque] = collections.defaultdict(collections.deque)
        self._violations: Dict[str, int] = collections.defaultdict(int)
        self._temp_bans: Dict[str, float] = {}
        self._temp_ban_count: Dict[str, int] = collections.defaultdict(int)
        self._perm_bans: set = set(BLACKLIST)
        self._active_conns: Dict[str, int] = collections.defaultdict(int)
        self._ua_patterns = [re.compile(p, re.IGNORECASE) for p in BLOCKED_UA_PATTERNS]
        self._path_patterns = [re.compile(p, re.IGNORECASE) for p in BLOCKED_PATH_PATTERNS]
        threading.Thread(target=self._cleanup_loop, daemon=True).start()
        self.logger.info("==============================================")
        self.logger.info("  DeployXCloud Shield — ACTIVE")
        self.logger.info("  Protecting: %s  →  :%d", BACKEND_URL, SHIELD_PORT)
        self.logger.info("  MongoDB: %s", "connected" if MONGODB_URL else "NOT SET")
        self.logger.info("  Dashboard: %s", DASHBOARD_URL or "NOT SET")
        self.logger.info("==============================================")

    def check_request(
        self, ip: str, path: str = "/",
        headers: Optional[Dict] = None, method: str = "GET", body_size: int = 0
    ) -> Tuple[bool, str]:
        headers = headers or {}
        now = time.time()

        if ip in WHITELIST:
            return True, "OK"

        if ip in self._perm_bans:
            reason = "PERMANENTLY BANNED"
            self._log_block(ip, path, reason)
            self.reporter.report(ip, path, method, reason, "blocked", headers.get("User-Agent", ""))
            return False, reason

        with self._lock:
            unban_at = self._temp_bans.get(ip, 0)
        if now < unban_at:
            remaining = int(unban_at - now)
            reason = f"TEMP BAN ({remaining}s left)"
            self._log_block(ip, path, reason)
            self.reporter.report(ip, path, method, reason, "blocked", headers.get("User-Agent", ""))
            return False, reason

        if method.upper() not in ALLOWED_METHODS:
            return self._violation(ip, path, method, f"INVALID METHOD: {method}", headers)

        if body_size > MAX_PAYLOAD_BYTES:
            return self._violation(ip, path, method, "PAYLOAD TOO LARGE", headers)

        ua = headers.get("User-Agent", headers.get("user-agent", ""))
        if not ua.strip():
            return self._violation(ip, path, method, "MISSING USER-AGENT", headers)

        for p in self._ua_patterns:
            if p.search(ua):
                return self._violation(ip, path, method, f"BLOCKED UA: {ua[:80]}", headers)

        for p in self._path_patterns:
            if p.search(urllib.parse.unquote(path)):
                return self._violation(ip, path, method, "SUSPICIOUS PATH", headers)

        with self._lock:
            bq = self._burst_log[ip]
            cutoff = now - 1.0
            while bq and bq[0] < cutoff:
                bq.popleft()
            if len(bq) >= BURST_LIMIT:
                return self._violation(ip, path, method, "BURST RATE LIMIT", headers)
            bq.append(now)

        with self._lock:
            q = self._req_log[ip]
            cutoff = now - RATE_LIMIT_WINDOW
            while q and q[0] < cutoff:
                q.popleft()
            if len(q) >= RATE_LIMIT_REQUESTS:
                return self._violation(ip, path, method, "RATE LIMIT EXCEEDED", headers)
            q.append(now)

        with self._lock:
            if self._active_conns.get(ip, 0) >= MAX_CONNECTIONS_PER_IP:
                return self._violation(ip, path, method, "TOO MANY CONNECTIONS", headers)

        if REPORT_ALLOWED:
            self.reporter.report(ip, path, method, "OK", "allowed", ua)
        return True, "OK"

    def _violation(self, ip, path, method, reason, headers):
        ua = headers.get("User-Agent", "")
        self._log_block(ip, path, reason)
        self.reporter.report(ip, path, method, reason, "blocked", ua)
        with self._lock:
            self._violations[ip] += 1
            count = self._violations[ip]
        if count >= BAN_AFTER_VIOLATIONS:
            self._temp_ban(ip)
        return False, reason

    def _temp_ban(self, ip):
        with self._lock:
            self._temp_bans[ip] = time.time() + TEMP_BAN_DURATION
            self._temp_ban_count[ip] = self._temp_ban_count.get(ip, 0) + 1
            n = self._temp_ban_count[ip]
            self._violations[ip] = 0
        self.logger.warning("TEMP BAN: %s for %ds (ban #%d)", ip, TEMP_BAN_DURATION, n)
        if n >= PERM_BAN_AFTER:
            self._perm_bans.add(ip)
            self._iptables_ban(ip)
            self.logger.critical("PERMANENT BAN: %s", ip)

    def open_conn(self, ip):
        with self._lock:
            self._active_conns[ip] = self._active_conns.get(ip, 0) + 1

    def close_conn(self, ip):
        with self._lock:
            self._active_conns[ip] = max(0, self._active_conns.get(ip, 1) - 1)

    def ban(self, ip, permanent=False):
        if permanent:
            self._perm_bans.add(ip)
            self._iptables_ban(ip)
            self.logger.warning("MANUAL PERM BAN: %s", ip)
        else:
            with self._lock:
                self._temp_bans[ip] = time.time() + TEMP_BAN_DURATION
            self.logger.warning("MANUAL TEMP BAN: %s", ip)

    def unban(self, ip):
        self._perm_bans.discard(ip)
        with self._lock:
            self._temp_bans.pop(ip, None)
            self._violations.pop(ip, None)
            self._temp_ban_count.pop(ip, None)
        self._iptables_unban(ip)
        self.logger.info("UNBANNED: %s", ip)

    def stats(self):
        with self._lock:
            return {
                "shield": "DeployXCloud Shield",
                "protecting": BACKEND_URL,
                "port": SHIELD_PORT,
                "tracked_ips": len(self._req_log),
                "temp_bans": len(self._temp_bans),
                "perm_bans": len(self._perm_bans),
                "active_connections": sum(self._active_conns.values()),
                "dashboard": DASHBOARD_URL or "not configured",
            }

    def _log_block(self, ip, path, reason):
        self.logger.warning("BLOCKED %s | %s | %s", ip, path[:200], reason)

    def _iptables_ban(self, ip):
        if not USE_IPTABLES:
            return
        try:
            subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"],
                           check=True, capture_output=True, timeout=5)
        except Exception as e:
            self.logger.error("iptables error: %s", e)

    def _iptables_unban(self, ip):
        if not USE_IPTABLES:
            return
        try:
            subprocess.run(["iptables", "-D", "INPUT", "-s", ip, "-j", "DROP"],
                           check=True, capture_output=True, timeout=5)
        except Exception:
            pass

    def _cleanup_loop(self):
        while True:
            time.sleep(60)
            now = time.time()
            with self._lock:
                expired = [ip for ip, t in self._temp_bans.items() if now >= t]
                for ip in expired:
                    del self._temp_bans[ip]
                    self.logger.info("Temp ban expired: %s", ip)
                cutoff = now - RATE_LIMIT_WINDOW
                for ip, q in list(self._req_log.items()):
                    while q and q[0] < cutoff:
                        q.popleft()
                    if not q:
                        del self._req_log[ip]


class ProxyHandler(BaseHTTPRequestHandler):
    shield: DeployXCloudShield = None

    def log_message(self, f, *a): pass

    def _ip(self):
        xff = self.headers.get("X-Forwarded-For", "")
        return xff.split(",")[0].strip() if xff else self.client_address[0]

    def _block(self, code, msg):
        body = json.dumps({"error": msg, "shield": "DeployXCloud Shield"}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Protected-By", "DeployXCloud Shield")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def _handle(self):
        ip = self._ip()
        self.shield.open_conn(ip)
        try:
            hdrs = dict(self.headers)
            clen = int(self.headers.get("Content-Length", 0) or 0)
            ok, reason = self.shield.check_request(ip, self.path, hdrs, self.command, clen)
            if not ok:
                self._block(429, reason)
                return
            target = BACKEND_URL.rstrip("/") + self.path
            fwd = {k: v for k, v in hdrs.items() if k.lower() not in ("host", "connection")}
            fwd.update({"X-Forwarded-For": ip, "X-Real-IP": ip,
                        "X-Protected-By": "DeployXCloud Shield"})
            body = self.rfile.read(clen) if clen > 0 else None
            req = urllib.request.Request(target, data=body, headers=fwd, method=self.command)
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    self.send_response(resp.status)
                    for k, v in resp.headers.items():
                        if k.lower() not in ("transfer-encoding", "connection"):
                            self.send_header(k, v)
                    self.send_header("X-Protected-By", "DeployXCloud Shield")
                    self.end_headers()
                    self.wfile.write(resp.read())
            except urllib.error.HTTPError as e:
                self.send_response(e.code)
                self.end_headers()
                self.wfile.write(e.read())
            except Exception as e:
                self._block(502, f"Backend error: {e}")
        finally:
            self.shield.close_conn(ip)

    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = do_OPTIONS = _handle


class ManagementHandler(BaseHTTPRequestHandler):
    shield: DeployXCloudShield = None

    def log_message(self, f, *a): pass

    def _json(self, code, data):
        body = json.dumps(data, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/stats":
            self._json(200, self.shield.stats())
        elif self.path.startswith("/ban/"):
            ip = self.path[5:]
            self.shield.ban(ip)
            self._json(200, {"ok": True, "banned": ip})
        elif self.path.startswith("/perm-ban/"):
            ip = self.path[10:]
            self.shield.ban(ip, permanent=True)
            self._json(200, {"ok": True, "perm_banned": ip})
        elif self.path.startswith("/unban/"):
            ip = self.path[7:]
            self.shield.unban(ip)
            self._json(200, {"ok": True, "unbanned": ip})
        else:
            self._json(404, {"error": "not found"})


def main():
    if not DDOS_APPLY_KEY:
        print("\n⚠️  WARNING: DDOS_APPLY_KEY is not set!")
        print("   Run: python3 gen_key.py  to generate a key,")
        print("   then paste it into the DDOS_APPLY_KEY variable at the top of this file.\n")

    shield = DeployXCloudShield()
    ProxyHandler.shield = shield
    ManagementHandler.shield = shield

    proxy = HTTPServer(("0.0.0.0", SHIELD_PORT), ProxyHandler)
    proxy.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    shield.logger.info("Proxy listening on :%d", SHIELD_PORT)

    if MANAGEMENT_PORT:
        mgmt = HTTPServer(("127.0.0.1", MANAGEMENT_PORT), ManagementHandler)
        threading.Thread(target=mgmt.serve_forever, daemon=True).start()
        shield.logger.info("Management API on :%d  (curl http://127.0.0.1:%d/stats)",
                           MANAGEMENT_PORT, MANAGEMENT_PORT)

    def shutdown(sig, frame):
        shield.logger.info("Shutting down...")
        threading.Thread(target=proxy.shutdown).start()
        sys.exit(0)

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    try:
        proxy.serve_forever()
    except KeyboardInterrupt:
        shield.logger.info("Stopped.")


if __name__ == "__main__":
    main()
