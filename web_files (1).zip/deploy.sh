#!/usr/bin/env bash
# DeployXCloud Shield — VPS Deploy Script
# Usage:  bash deploy.sh
set -e

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()    { echo -e "${GREEN}[✔]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✘]${NC} $1"; exit 1; }
section() { echo -e "\n${GREEN}══════════════════════════════════════${NC}"; echo -e "  $1"; echo -e "${GREEN}══════════════════════════════════════${NC}"; }

section "DeployXCloud Shield — Setup"

# ── 1. Check .env ────────────────────────────────────────────────────────────
if [ ! -f .env ]; then
  if [ -f .env.example ]; then
    cp .env.example .env
    warn ".env not found — copied from .env.example"
    warn "Fill in MONGODB_URI and DDOS_APPLY_KEY in .env, then re-run: bash deploy.sh"
    exit 0
  else
    error ".env file not found. Create it with MONGODB_URI and DDOS_APPLY_KEY."
  fi
fi

# Load .env
set -a; source .env; set +a
info ".env loaded"

[ -z "$MONGODB_URI"    ] && warn "MONGODB_URI not set — running without database persistence."
[ -z "$DDOS_APPLY_KEY" ] && warn "DDOS_APPLY_KEY not set — attack reports won't be authenticated."

DASHBOARD_PORT="${PORT:-3000}"

# ── 2. Node.js ───────────────────────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  section "Installing Node.js 20"
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
info "Node.js $(node -v)"

# ── 3. pnpm ──────────────────────────────────────────────────────────────────
if ! command -v pnpm &>/dev/null; then
  npm install -g pnpm
fi
info "pnpm $(pnpm -v)"

# ── 4. PM2 ───────────────────────────────────────────────────────────────────
if ! command -v pm2 &>/dev/null; then
  npm install -g pm2
fi
info "PM2 $(pm2 -v)"

# ── 5. Install dependencies ──────────────────────────────────────────────────
section "Installing dependencies"
pnpm install --frozen-lockfile || pnpm install
info "Dependencies installed"

# ── 6. Build frontend ────────────────────────────────────────────────────────
section "Building frontend"
BASE_PATH=/ PORT="$DASHBOARD_PORT" pnpm --filter @workspace/shield-dashboard run build
info "Frontend built"

# ── 7. Build API server ──────────────────────────────────────────────────────
section "Building API server"
pnpm --filter @workspace/api-server run build
info "API server built"

# ── 8. Start with PM2 ───────────────────────────────────────────────────────
section "Starting with PM2"

# Write a plain-JS ecosystem file (not .cjs — PM2 needs .js at root level)
cat > ecosystem.config.js << ECOSYSTEM
module.exports = {
  apps: [{
    name: 'shield-dashboard',
    script: 'artifacts/api-server/dist/index.cjs',
    env: {
      NODE_ENV:       'production',
      PORT:           '${DASHBOARD_PORT}',
      MONGODB_URI:    '${MONGODB_URI:-}',
      DDOS_APPLY_KEY: '${DDOS_APPLY_KEY:-}',
    }
  }]
};
ECOSYSTEM

pm2 delete shield-dashboard 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save
info "PM2 started: shield-dashboard on port ${DASHBOARD_PORT}"

# ── 9. Firewall ──────────────────────────────────────────────────────────────
if command -v ufw &>/dev/null; then
  ufw allow "${DASHBOARD_PORT}"/tcp 2>/dev/null || true
  info "Firewall: port ${DASHBOARD_PORT} opened"
fi

# ── Done ─────────────────────────────────────────────────────────────────────
section "Done!"
SERVER_IP=$(curl -s --max-time 5 ifconfig.me 2>/dev/null || echo "YOUR_VPS_IP")
echo ""
echo "  Dashboard → http://${SERVER_IP}:${DASHBOARD_PORT}"
echo ""
echo "  pm2 logs shield-dashboard     — live logs"
echo "  pm2 restart shield-dashboard  — restart"
echo "  pm2 status                    — check status"
echo ""
