# DeployXCloud Shield — Setup Guide

> Two-VPS DDoS protection system for Pterodactyl panel.
> **VPS 1** runs the Python reverse proxy. **VPS 2** runs the React dashboard + API.

---

## Overview

```
Browser → VPS 1 (ddos_protection.py on port 80)
                ↓ proxies clean traffic
           Pterodactyl Panel (port 8080 or wherever it runs)
                ↓ reports attacks
VPS 2 (Dashboard + API on port 3000) ← MongoDB Atlas
```

---

## Step 1 — MongoDB Atlas (free, takes ~3 minutes)

1. Go to https://cloud.mongodb.com → create free account
2. Create a free **M0** cluster
3. Add a database user (username + password)
4. Allow all IPs: **Network Access → Add IP → 0.0.0.0/0**
5. Click **Connect → Drivers** and copy the URI:
   ```
   mongodb+srv://USER:PASS@cluster0.xxxxx.mongodb.net/shield?retryWrites=true&w=majority
   ```
6. Save this URI — you'll need it in both VPS setups.

---

## Step 2 — Generate your API key

On **any** machine with Python 3 installed:

```bash
python3 gen_key.py
```

Copy the key it prints — this is your `DDOS_APPLY_KEY`.
Both VPS 1 and VPS 2 must use the **same key**.

---

## Step 3 — VPS 2 (Dashboard)

Upload `web_files.zip` and run:

```bash
cd /var/www
unzip web_files.zip -d dashboard
cd dashboard

# Copy and fill in the .env file
cp .env.example .env
nano .env
```

In `.env` set:
```
MONGODB_URI=mongodb+srv://USER:PASS@cluster0.xxxxx.mongodb.net/shield?retryWrites=true&w=majority
DDOS_APPLY_KEY=your-key-from-gen_key.py
PORT=3000
```

Then run the one-command deploy script — it installs Node, pnpm, PM2, builds the app, and starts it:

```bash
bash deploy.sh
```

After it finishes, your dashboard is live at:
```
http://YOUR_VPS2_IP:3000
```

To make it survive reboots:
```bash
pm2 startup
# Copy and run the command it prints, then:
pm2 save
```

### Useful commands
```bash
pm2 logs shield-dashboard     # live logs
pm2 restart shield-dashboard  # restart after .env changes
pm2 status                    # check if running
```

---

## Step 4 — VPS 1 (Pterodactyl / Reverse Proxy)

Upload `py.zip` and extract:

```bash
apt update && apt install -y python3 python3-pip
pip3 install aiohttp motor pymongo

mkdir -p /opt/shield && cd /opt/shield
# upload ddos_protection.py and gen_key.py here

nano ddos_protection.py
```

At the **top of the file**, set these three variables:

```python
MONGODB_URL    = "mongodb+srv://USER:PASS@cluster0.xxxxx.mongodb.net/shield?retryWrites=true&w=majority"
DDOS_APPLY_KEY = "your-key-from-gen_key.py"          # must match VPS 2
DASHBOARD_URL  = "http://YOUR_VPS2_IP:3000"           # your dashboard address
```

Start with PM2:
```bash
npm install -g pm2
pm2 start "python3 ddos_protection.py" --name ddos-shield
pm2 save
pm2 startup
```

> **Port note:** The proxy listens on `SHIELD_PORT = 7070` by default.
> To receive traffic on port 80, either change `SHIELD_PORT` to 80 and run with sudo,
> or put Nginx in front:

```nginx
server {
    listen 80;
    server_name your-panel-domain.com;
    location / {
        proxy_pass http://127.0.0.1:7070;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## Step 5 — Test it

1. Open `http://YOUR_VPS2_IP:3000` — you should see the verification screen
2. Pass the check — you're in the dashboard
3. Send test traffic through VPS 1: `curl http://YOUR_VPS1_IP:7070`
4. Watch attack events appear in real time on the dashboard

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `npm run dev` / `npm start` errors | Use `bash deploy.sh` — that's the correct start method |
| Dashboard shows blank page | Run `pm2 logs shield-dashboard` — check for MONGODB errors |
| MongoDB connection failed | Check MONGODB_URI in .env; make sure 0.0.0.0/0 is in Atlas allowlist |
| Port 3000 not reachable | `ufw allow 3000/tcp` or check your VPS firewall panel |
| Python proxy not reporting attacks | Check DDOS_APPLY_KEY matches on both VPS; check DASHBOARD_URL is correct |
| Re-verification loops | Normal — sessions re-verify every 15 minutes or if your network changes |

---

## File Reference

| File | Purpose |
|------|---------|
| `deploy.sh` | **One-command deploy for VPS 2** — run this first |
| `.env.example` | Template for environment variables |
| `ddos_protection.py` | Python reverse proxy — runs on VPS 1 |
| `gen_key.py` | Generates a secure random API key |
| `artifacts/api-server/` | Express + MongoDB backend API |
| `artifacts/shield-dashboard/` | React frontend dashboard |
