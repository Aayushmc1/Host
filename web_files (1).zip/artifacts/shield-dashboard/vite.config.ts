import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

const port    = Number(process.env.PORT     || 3000);
const basePath =        process.env.BASE_PATH || "/";

// Replit-specific plugins — only load when running inside Replit
const replitPlugins: ReturnType<typeof defineConfig>["plugins"] = [];
if (process.env.REPL_ID) {
  const [cartographer, banner, errorOverlay] = await Promise.all([
    import("@replit/vite-plugin-cartographer"),
    import("@replit/vite-plugin-dev-banner"),
    import("@replit/vite-plugin-runtime-error-modal"),
  ]);
  if (process.env.NODE_ENV !== "production") {
    replitPlugins.push(
      cartographer.cartographer({ root: path.resolve(import.meta.dirname, "..") }),
      banner.devBanner(),
    );
    replitPlugins.push(errorOverlay.default());
  }
}

export default defineConfig({
  base: basePath,
  plugins: [react(), tailwindcss(), ...replitPlugins],
  resolve: {
    alias: {
      "@":       path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(import.meta.dirname, "..", "..", "attached_assets"),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir:      path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port,
    host:         "0.0.0.0",
    allowedHosts: true,
    fs: { strict: true, deny: ["**/.*"] },
  },
  preview: {
    port,
    host:         "0.0.0.0",
    allowedHosts: true,
  },
});
