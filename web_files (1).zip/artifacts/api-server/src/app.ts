import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import router from "./routes";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app: Express = express();

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// ─── API routes ─────────────────────────────────────────────────────────────
app.use("/api", router);

// ─── Serve frontend static files in production ──────────────────────────────
// In production the built CJS bundle sits at:
//   <project-root>/artifacts/api-server/dist/index.cjs
// The built frontend sits at:
//   <project-root>/artifacts/shield-dashboard/dist/public
//
// __dirname resolves to <project-root>/artifacts/api-server/dist  (or src in dev)
// so we go up two levels then into the frontend dist.
if (process.env.NODE_ENV === "production") {
  const frontendDist = path.resolve(__dirname, "..", "..", "shield-dashboard", "dist", "public");

  // Serve static assets (JS, CSS, images, etc.)
  app.use(express.static(frontendDist));

  // SPA fallback — send index.html for any non-API route
  app.get("*", (_req: Request, res: Response) => {
    res.sendFile(path.join(frontendDist, "index.html"));
  });
}

export default app;
