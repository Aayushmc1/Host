# DeployXCloud Shield — Full Setup Guide

## Overview

You need **two VPS machines**:

| VPS | Purpose | What runs |
|-----|---------|-----------|
| **VPS 1** (Pterodactyl VPS) | Game panel host | `ddos_protection.py` in front of Pterodactyl on port 80 |
| **VPS 2** (Dashboard VPS) | Shield dashboard | The website on port 3000 + API server |

Both connect to the same **MongoDB** database to share data in real-time.

---

## Step 1 — MongoDB Setup

1. Go to [mongodb.com/atlas](https://www.mongodb.com/atlas) and create a free account
2. Create a new **free cluster**
3. Create a database user (remember the username and password)
4. Click **Connect** → **Drivers** → copy the connection string
5. It looks like:
   ```
   mongodb+srv://username:password@cluster.mongodb.net/shield
   ```
6. Save this — you will need it in both VPS setups

---

## Step 2 — VPS 2 (Dashboard Website Setup)

This is the VPS where the control panel website will run at port 3000.

### Requirements
- Ubuntu 20.04 / 22.04
- Node.js 18+ and pnpm
- PM2 process manager

### Install dependencies

```bash
# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install pnpm
npm install -g pnpm

# Install PM2
npm install -g pm2
```

### Upload and configure the website

```bash
# Create a folder for the dashboard
mkdir -p /var/www/shield-dashboard
cd /var/www/shield-dashboard

# Upload the contents of web_files.zip here, then:
unzip web_files.zip -d .

# Copy the example .env file
cp .env.example .env

# Open the .env file and fill in your values
nano .env
```

### Fill in the .env file

```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/shield
DDOS_APPLY_KEY=dxs_xxxxxxxxxxxxxxxxxxxx   # You will get this in Step 3
PORT=3000
NODE_ENV=production
```

### Install packages and build

```bash
pnpm install
pnpm run build
```

### Start with PM2

```bash
# Start the API server
pm2 start "node artifacts/api-server/dist/index.cjs" --name shield-api

# Start the dashboard website
# (serve the built frontend with a static server)
npm install -g serve
pm2 start "serve -s artifacts/shield-dashboard/dist -l 3000" --name shield-web

# Save PM2 so it restarts on reboot
pm2 save
pm2 startup
```

### Open firewall port

```bash
sudo ufw allow 3000
```

Your dashboard will be available at: `http://your-dashboard-vps-ip:3000`

---

## Step 3 — VPS 1 (Pterodactyl VPS Setup)

This is the VPS where Pterodactyl panel runs on port 80. The shield proxy sits in front of it.

### Requirements
- Python 3.8+
- PM2 or screen

### Upload the Python files

Upload the contents of `py.zip` to `/var/www/pterodactyl/` (or any folder you like):

```bash
mkdir -p /var/www/pterodactyl-shield
cd /var/www/pterodactyl-shield
# Upload ddos_protection.py and gen_key.py here
```

### Generate your secret key

```bash
python3 gen_key.py
```

This will print something like:
```
KEY:  dxs_a1b2c3d4e5f6g7h8i9j0...
```

**Copy this key.** You need it in two places:
- `ddos_protection.py` → `DDOS_APPLY_KEY`
- Dashboard VPS `.env` → `DDOS_APPLY_KEY`

### Configure ddos_protection.py

Open the file and fill in the three config variables at the very top:

```bash
nano ddos_protection.py
```

```python
MONGODB_URL    = "mongodb+srv://username:password@cluster.mongodb.net/shield"
DDOS_APPLY_KEY = "dxs_a1b2c3d4..."     # Key from gen_key.py
DASHBOARD_URL  = "http://YOUR_DASHBOARD_VPS_IP:3000/api"
```

Save and close (`Ctrl+X`, then `Y`, then `Enter`).

### Install PM2 (if not already installed)

```bash
npm install -g pm2
# or if npm not available:
pip3 install supervisor
```

### Start the shield with PM2

```bash
pm2 start "python3 ddos_protection.py" --name ddos
pm2 save
pm2 startup
```

### Verify it's running

```bash
pm2 status

# Check logs
pm2 logs ddos

# Check stats via management API (local only)
curl http://127.0.0.1:9090/stats
```

### Configure Nginx (recommended — put Nginx in front of the shield)

If you want to keep port 80 for Nginx and have the shield on port 7070:

```nginx
# /etc/nginx/sites-available/pterodactyl
server {
    listen 80;
    server_name your-pterodactyl-domain.com;

    location / {
        proxy_pass http://127.0.0.1:7070;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
sudo nginx -t
sudo systemctl reload nginx
```

**Or** just point port 80 directly to the shield:
Edit `ddos_protection.py` and set `SHIELD_PORT = 80`, then run with sudo:
```bash
sudo pm2 start "python3 ddos_protection.py" --name ddos
```

---

## Step 4 — Verify Everything Works

1. Open your dashboard at `http://your-dashboard-vps-ip:3000`
2. Pass the verification screen
3. Go to **Dashboard** — you should see **Protection Status: ACTIVE**
4. Make a test request to your Pterodactyl panel
5. Go to **Attack Events** — you should see the request appear
6. Try visiting a blocked path like `http://your-pterodactyl-ip:7070/wp-admin`
7. Go back to the dashboard — it should show the blocked event

---

## Management Commands (on Pterodactyl VPS)

```bash
# View shield logs live
pm2 logs ddos

# Restart the shield
pm2 restart ddos

# Stop the shield
pm2 stop ddos

# Manually ban an IP
curl http://127.0.0.1:9090/ban/1.2.3.4

# Permanently ban an IP
curl http://127.0.0.1:9090/perm-ban/1.2.3.4

# Unban an IP
curl http://127.0.0.1:9090/unban/1.2.3.4

# View live stats
curl http://127.0.0.1:9090/stats
```

---

## Dashboard Features

| Page | What it shows |
|------|--------------|
| **Dashboard** | Live stats: total requests, blocked, threats, requests/min — auto-refreshes every 5s |
| **Attack Events** | Full log of every blocked request with IP, path, reason, timestamp |
| **IP Manager** | Manage blacklist, whitelist, and temp-bans — add or remove IPs |
| **Top Attackers** | Leaderboard of IPs with most blocked requests |

---

## Security Notes

- The `DDOS_APPLY_KEY` must be **the same** in both `ddos_protection.py` and `.env`
- The management API (port 9090) is bound to `127.0.0.1` — it is **not exposed** to the internet
- The shield logs everything to `ddos_shield.log` in the same folder
- Permanent bans survive restarts (stored in MongoDB)
- The dashboard re-verifies you every **15 minutes** and if your **network/IP changes**

---

## Folder Structure

```
VPS 1 (Pterodactyl VPS):
/var/www/pterodactyl-shield/
├── ddos_protection.py     ← Main shield proxy
├── gen_key.py             ← Key generator (run once)
├── shield_key.txt         ← Generated key (keep safe)
└── ddos_shield.log        ← Auto-created log file

VPS 2 (Dashboard VPS):
/var/www/shield-dashboard/
├── .env                   ← Your config (MONGODB_URI, DDOS_APPLY_KEY)
├── artifacts/
│   ├── api-server/        ← Express API (serves /api routes)
│   └── shield-dashboard/  ← React dashboard frontend
└── lib/                   ← Shared libraries
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Dashboard shows 0 events | Check `DASHBOARD_URL` in `ddos_protection.py` is correct |
| MongoDB not connecting | Check `MONGODB_URI` format and whitelist your VPS IP in MongoDB Atlas |
| Shield not blocking | Check `pm2 logs ddos` for errors |
| Port 80 permission denied | Run with `sudo` or use Nginx proxy as described above |
| Key mismatch error | Make sure `DDOS_APPLY_KEY` is identical in both files |
| Re-verification loop | Clear browser localStorage: `localStorage.clear()` in browser console |
