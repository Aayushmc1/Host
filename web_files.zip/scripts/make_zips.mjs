/**
 * Creates py.zip and web_files.zip using only Node.js built-ins.
 * Run: node scripts/make_zips.mjs
 */
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { createWriteStream } from 'fs';

const ROOT = path.resolve('.');

// ── Helpers ────────────────────────────────────────────────────────────────
const SKIP_DIRS  = new Set(['node_modules', '.git', 'dist', '__pycache__', '.turbo']);
const SKIP_EXTS  = new Set(['.tsbuildinfo', '.log', '.pyc']);

function collectFiles(dir, base = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const e of entries) {
    if (SKIP_DIRS.has(e.name)) continue;
    const rel = base ? `${base}/${e.name}` : e.name;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      files.push(...collectFiles(full, rel));
    } else {
      const ext = path.extname(e.name);
      if (!SKIP_EXTS.has(ext)) files.push({ rel, full });
    }
  }
  return files;
}

// ── Build zip using 'tar' + python's zipfile via stdin workaround ──────────
// Actually we'll write a simple ZIP builder in pure JS (no external libs)
// using the ZIP local file header format.

function u32le(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32LE(n);
  return b;
}
function u16le(n) {
  const b = Buffer.alloc(2);
  b.writeUInt16LE(n);
  return b;
}

import zlib from 'zlib';

function crc32(buf) {
  const table = (() => {
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[i] = c;
    }
    return t;
  })();
  let crc = 0xFFFFFFFF;
  for (const byte of buf) crc = table[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function buildZip(fileList) {
  const parts = [];
  const central = [];
  let offset = 0;

  for (const { rel, full } of fileList) {
    const raw = fs.readFileSync(full);
    const compressed = zlib.deflateRawSync(raw, { level: 6 });
    const crc = crc32(raw);
    const nameBytes = Buffer.from(rel, 'utf8');
    const now = new Date();
    const dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) >>> 0;
    const dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) >>> 0;

    const localHeader = Buffer.concat([
      Buffer.from([0x50, 0x4B, 0x03, 0x04]), // signature
      u16le(20),                              // version needed
      u16le(0),                               // flags
      u16le(8),                               // deflate
      u16le(dosTime),
      u16le(dosDate),
      u32le(crc),
      u32le(compressed.length),
      u32le(raw.length),
      u16le(nameBytes.length),
      u16le(0),                               // extra
      nameBytes,
    ]);

    const centralEntry = Buffer.concat([
      Buffer.from([0x50, 0x4B, 0x01, 0x02]), // signature
      u16le(20), u16le(20),                  // version made/needed
      u16le(0),                               // flags
      u16le(8),                               // deflate
      u16le(dosTime), u16le(dosDate),
      u32le(crc),
      u32le(compressed.length),
      u32le(raw.length),
      u16le(nameBytes.length),
      u16le(0), u16le(0), u16le(0), u16le(0), // extra, comment, disk, attr
      u32le(0),                               // ext attr
      u32le(offset),                          // local header offset
      nameBytes,
    ]);

    parts.push(localHeader, compressed);
    central.push(centralEntry);
    offset += localHeader.length + compressed.length;
  }

  const centralBuf = Buffer.concat(central);
  const eocd = Buffer.concat([
    Buffer.from([0x50, 0x4B, 0x05, 0x06]),   // end of central dir
    u16le(0), u16le(0),                       // disk numbers
    u16le(central.length), u16le(central.length),
    u32le(centralBuf.length),
    u32le(offset),
    u16le(0),
  ]);

  return Buffer.concat([...parts, centralBuf, eocd]);
}

// ── py.zip ─────────────────────────────────────────────────────────────────
console.log('Building py.zip...');
const pyFiles = [
  { rel: 'ddos_protection.py', full: path.join(ROOT, 'ddos_protection.py') },
  { rel: 'gen_key.py',         full: path.join(ROOT, 'gen_key.py') },
];
const pyZip = buildZip(pyFiles);
fs.writeFileSync('py.zip', pyZip);
console.log(`py.zip — ${(pyZip.length / 1024).toFixed(1)} KB  (${pyFiles.length} files)`);

// ── web_files.zip ──────────────────────────────────────────────────────────
console.log('Building web_files.zip...');
const webFiles = [];
const rootFiles = [
  'package.json','pnpm-workspace.yaml','tsconfig.json',
  'tsconfig.base.json','.env.example','SETUP_GUIDE.md',
];
for (const f of rootFiles) {
  const full = path.join(ROOT, f);
  if (fs.existsSync(full)) webFiles.push({ rel: f, full });
}
const webDirs = [
  'artifacts/shield-dashboard',
  'artifacts/api-server',
  'lib',
  'scripts',
];
for (const d of webDirs) {
  const full = path.join(ROOT, d);
  if (fs.existsSync(full)) webFiles.push(...collectFiles(full, d));
}
const webZip = buildZip(webFiles);
fs.writeFileSync('web_files.zip', webZip);
console.log(`web_files.zip — ${(webZip.length / 1024).toFixed(1)} KB  (${webFiles.length} files)`);
console.log('Done!');
