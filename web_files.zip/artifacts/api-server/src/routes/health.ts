import { Router, type IRouter, type Request, type Response } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/healthz", (_req: Request, res: Response) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

// Returns the caller's IP — used by the dashboard for network-change detection
router.get("/my-ip", (req: Request, res: Response) => {
  const xff = req.headers["x-forwarded-for"];
  const ip  = (Array.isArray(xff) ? xff[0] : xff?.split(",")[0])?.trim()
    ?? req.socket.remoteAddress
    ?? "unknown";
  res.json({ ip });
});

export default router;
