import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "crypto";
import {
  connectMongo,
  isMongoConnected,
  AttackEventModel,
  IpRuleModel,
  ShieldStatsModel,
  memStore,
} from "../lib/mongodb.js";

const router: IRouter = Router();

// Ensure mongo is connected on first use
let mongoInitiated = false;
async function ensureMongo() {
  if (!mongoInitiated) {
    mongoInitiated = true;
    await connectMongo();
  }
}

// ─── GET /shield/stats ──────────────────────────────────────────────────────
router.get("/stats", async (_req: Request, res: Response) => {
  await ensureMongo();
  try {
    let stats;
    let tempBannedIps = 0;
    let permBannedIps = 0;
    let whitelistedIps = 0;

    if (isMongoConnected()) {
      stats = await ShieldStatsModel.findOne().lean();
      if (!stats) {
        stats = { totalRequests: 0, totalBlocked: 0, totalAllowed: 0, startedAt: new Date() };
      }
      tempBannedIps = await IpRuleModel.countDocuments({ type: "temp-ban" });
      permBannedIps = await IpRuleModel.countDocuments({ type: "blacklist" });
      whitelistedIps = await IpRuleModel.countDocuments({ type: "whitelist" });
    } else {
      stats = memStore.stats;
      for (const r of memStore.rules.values()) {
        if (r.type === "temp-ban") tempBannedIps++;
        else if (r.type === "blacklist") permBannedIps++;
        else if (r.type === "whitelist") whitelistedIps++;
      }
    }

    // Compute requests per minute over last 60s
    let recentEvents: Array<{ action: string; timestamp: Date }> = [];
    if (isMongoConnected()) {
      const since = new Date(Date.now() - 60_000);
      recentEvents = await AttackEventModel.find({ timestamp: { $gte: since } })
        .select("action timestamp")
        .lean();
    } else {
      const since = Date.now() - 60_000;
      recentEvents = memStore.events.filter(e => e.timestamp.getTime() >= since);
    }

    const requestsPerMinute = recentEvents.length;
    const blockedPerMinute = recentEvents.filter(e => e.action === "blocked").length;
    const activeThreats = tempBannedIps;
    const uptimeSecs = stats.startedAt
      ? Math.floor((Date.now() - new Date(stats.startedAt).getTime()) / 1000)
      : 0;

    res.json({
      totalRequests: stats.totalRequests,
      totalBlocked: stats.totalBlocked,
      totalAllowed: stats.totalAllowed,
      activeThreats,
      tempBannedIps,
      permBannedIps,
      whitelistedIps,
      requestsPerMinute,
      blockedPerMinute,
      protectionStatus: "active",
      uptime: uptimeSecs,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── GET /shield/events ─────────────────────────────────────────────────────
router.get("/events", async (req: Request, res: Response) => {
  await ensureMongo();
  const limit = Math.min(Number(req.query.limit) || 100, 500);
  const page = Math.max(Number(req.query.page) || 1, 1);
  const filter = (req.query.filter as string) || "all";
  const skip = (page - 1) * limit;

  try {
    let events: Array<unknown>;
    let total: number;

    const query: Record<string, unknown> = {};
    if (filter === "blocked") query.action = "blocked";
    if (filter === "allowed") query.action = "allowed";

    if (isMongoConnected()) {
      total = await AttackEventModel.countDocuments(query);
      const raw = await AttackEventModel.find(query)
        .sort({ timestamp: -1 })
        .skip(skip)
        .limit(limit)
        .lean();
      events = raw.map((e: Record<string, unknown>) => ({
        id: String(e._id),
        ip: e.ip,
        path: e.path,
        method: e.method,
        reason: e.reason,
        action: e.action,
        userAgent: e.userAgent || "",
        country: e.country || "",
        timestamp: e.timestamp,
      }));
    } else {
      let all = [...memStore.events];
      if (filter !== "all") all = all.filter(e => e.action === filter);
      all.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      total = all.length;
      events = all.slice(skip, skip + limit);
    }

    res.json({
      events,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── GET /shield/ips ────────────────────────────────────────────────────────
router.get("/ips", async (_req: Request, res: Response) => {
  await ensureMongo();
  try {
    let rules: Array<unknown>;
    let total: number;

    if (isMongoConnected()) {
      const raw = await IpRuleModel.find().sort({ createdAt: -1 }).lean();
      rules = raw.map((r: Record<string, unknown>) => ({
        id: String(r._id),
        ip: r.ip,
        type: r.type,
        reason: r.reason || "",
        createdAt: r.createdAt,
        expiresAt: r.expiresAt || null,
        requestCount: r.requestCount || 0,
      }));
      total = rules.length;
    } else {
      rules = [...memStore.rules.values()];
      total = rules.length;
    }

    res.json({ rules, total });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── POST /shield/ips ───────────────────────────────────────────────────────
router.post("/ips", async (req: Request, res: Response) => {
  await ensureMongo();
  const { ip, type, reason } = req.body as { ip: string; type: string; reason?: string };
  if (!ip || !type) {
    res.status(400).json({ error: "ip and type are required" });
    return;
  }

  try {
    if (isMongoConnected()) {
      await IpRuleModel.findOneAndUpdate(
        { ip },
        { ip, type, reason: reason || "", requestCount: 0 },
        { upsert: true, new: true }
      );
      const saved = await IpRuleModel.findOne({ ip }).lean() as Record<string, unknown>;
      res.status(201).json({
        id: String(saved!._id),
        ip: saved!.ip,
        type: saved!.type,
        reason: saved!.reason || "",
        createdAt: saved!.createdAt,
        expiresAt: saved!.expiresAt || null,
        requestCount: saved!.requestCount || 0,
      });
    } else {
      const id = randomUUID();
      const rule = {
        id,
        ip,
        type: type as "blacklist" | "whitelist" | "temp-ban",
        reason: reason || "",
        createdAt: new Date(),
        requestCount: 0,
      };
      memStore.rules.set(ip, rule);
      res.status(201).json(rule);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── DELETE /shield/ips/:ip ─────────────────────────────────────────────────
router.delete("/ips/:ip", async (req: Request, res: Response) => {
  await ensureMongo();
  const { ip } = req.params;

  try {
    if (isMongoConnected()) {
      await IpRuleModel.deleteOne({ ip });
    } else {
      memStore.rules.delete(ip);
    }
    res.json({ success: true, message: `IP ${ip} rule removed` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── GET /shield/top-attackers ───────────────────────────────────────────────
router.get("/top-attackers", async (req: Request, res: Response) => {
  await ensureMongo();
  const limit = Math.min(Number(req.query.limit) || 10, 50);

  try {
    type AggResult = { _id: string; requestCount: number; blockedCount: number; lastSeen: Date };
    let aggregated: AggResult[];

    if (isMongoConnected()) {
      aggregated = await AttackEventModel.aggregate([
        {
          $group: {
            _id: "$ip",
            requestCount: { $sum: 1 },
            blockedCount: { $sum: { $cond: [{ $eq: ["$action", "blocked"] }, 1, 0] } },
            lastSeen: { $max: "$timestamp" },
          },
        },
        { $sort: { blockedCount: -1 } },
        { $limit: limit },
      ]);
    } else {
      const map = new Map<string, AggResult>();
      for (const e of memStore.events) {
        const cur = map.get(e.ip) || {
          _id: e.ip,
          requestCount: 0,
          blockedCount: 0,
          lastSeen: e.timestamp,
        };
        cur.requestCount++;
        if (e.action === "blocked") cur.blockedCount++;
        if (e.timestamp > cur.lastSeen) cur.lastSeen = e.timestamp;
        map.set(e.ip, cur);
      }
      aggregated = [...map.values()]
        .sort((a, b) => b.blockedCount - a.blockedCount)
        .slice(0, limit);
    }

    // Fetch IP rule status
    const attackers = await Promise.all(
      aggregated.map(async (a) => {
        let status = "active";
        if (isMongoConnected()) {
          const rule = await IpRuleModel.findOne({ ip: a._id }).lean() as Record<string, unknown> | null;
          if (rule) status = rule.type as string;
        } else {
          const rule = memStore.rules.get(a._id);
          if (rule) status = rule.type;
        }
        return {
          ip: a._id,
          requestCount: a.requestCount,
          blockedCount: a.blockedCount,
          lastSeen: a.lastSeen,
          country: "",
          status,
        };
      })
    );

    res.json({ attackers });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── GET /shield/chart ───────────────────────────────────────────────────────
router.get("/chart", async (_req: Request, res: Response) => {
  await ensureMongo();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);

  try {
    type ChartAgg = { _id: { hour: number }; requests: number; blocked: number };
    let raw: ChartAgg[];

    if (isMongoConnected()) {
      raw = await AttackEventModel.aggregate([
        { $match: { timestamp: { $gte: since } } },
        {
          $group: {
            _id: { hour: { $hour: "$timestamp" } },
            requests: { $sum: 1 },
            blocked: { $sum: { $cond: [{ $eq: ["$action", "blocked"] }, 1, 0] } },
          },
        },
        { $sort: { "_id.hour": 1 } },
      ]);
    } else {
      const map = new Map<number, ChartAgg>();
      for (const e of memStore.events) {
        if (e.timestamp < since) continue;
        const hour = e.timestamp.getHours();
        const cur = map.get(hour) || { _id: { hour }, requests: 0, blocked: 0 };
        cur.requests++;
        if (e.action === "blocked") cur.blocked++;
        map.set(hour, cur);
      }
      raw = [...map.values()].sort((a, b) => a._id.hour - b._id.hour);
    }

    const points = raw.map((p) => ({
      time: `${String(p._id.hour).padStart(2, "0")}:00`,
      requests: p.requests,
      blocked: p.blocked,
    }));

    res.json({ points });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

// ─── POST /shield/report (called by Python shield) ───────────────────────────
router.post("/report", async (req: Request, res: Response) => {
  await ensureMongo();
  const { ip, path, method, reason, action, userAgent, shieldKey } = req.body as {
    ip: string;
    path: string;
    method: string;
    reason: string;
    action: string;
    userAgent?: string;
    shieldKey?: string;
  };

  // Optional shield key auth
  const expectedKey = process.env.SHIELD_API_KEY;
  if (expectedKey && shieldKey !== expectedKey) {
    res.status(401).json({ success: false, message: "Unauthorized" });
    return;
  }

  if (!ip || !path || !method || !reason || !action) {
    res.status(400).json({ success: false, message: "Missing fields" });
    return;
  }

  try {
    if (isMongoConnected()) {
      await AttackEventModel.create({
        ip, path, method, reason,
        action: action as "blocked" | "allowed",
        userAgent: userAgent || "",
        country: "",
        timestamp: new Date(),
      });
      // Upsert stats
      await ShieldStatsModel.findOneAndUpdate(
        {},
        {
          $inc: {
            totalRequests: 1,
            totalBlocked: action === "blocked" ? 1 : 0,
            totalAllowed: action === "allowed" ? 1 : 0,
          },
          $setOnInsert: { startedAt: new Date() },
        },
        { upsert: true }
      );
      // Increment requestCount for IP rule if exists
      if (action === "blocked") {
        await IpRuleModel.findOneAndUpdate(
          { ip },
          { $inc: { requestCount: 1 } }
        );
      }
    } else {
      const id = randomUUID();
      memStore.events.push({
        id, ip, path, method, reason,
        action: action as "blocked" | "allowed",
        userAgent: userAgent || "",
        country: "",
        timestamp: new Date(),
      });
      if (memStore.events.length > 10_000) {
        memStore.events.splice(0, memStore.events.length - 10_000);
      }
      memStore.stats.totalRequests++;
      if (action === "blocked") memStore.stats.totalBlocked++;
      else memStore.stats.totalAllowed++;
    }

    res.status(201).json({ success: true, message: "Event recorded" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal error" });
  }
});

export default router;
