import mongoose from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI || "";

let isConnected = false;

export async function connectMongo(): Promise<void> {
  if (isConnected) return;
  if (!MONGODB_URI) {
    console.warn("[MongoDB] MONGODB_URI not set — running without persistence.");
    return;
  }
  try {
    await mongoose.connect(MONGODB_URI);
    isConnected = true;
    console.log("[MongoDB] Connected successfully.");
  } catch (err) {
    console.error("[MongoDB] Connection failed:", err);
  }
}

export function isMongoConnected(): boolean {
  return isConnected && mongoose.connection.readyState === 1;
}

// ─── Schemas ────────────────────────────────────────────────────────────────

const attackEventSchema = new mongoose.Schema(
  {
    ip:        { type: String, required: true, index: true },
    path:      { type: String, required: true },
    method:    { type: String, required: true },
    reason:    { type: String, required: true },
    action:    { type: String, enum: ["blocked", "allowed"], required: true },
    userAgent: { type: String, default: "" },
    country:   { type: String, default: "" },
    timestamp: { type: Date, default: Date.now, index: true },
  },
  { collection: "attack_events" }
);

const ipRuleSchema = new mongoose.Schema(
  {
    ip:        { type: String, required: true, unique: true },
    type:      { type: String, enum: ["blacklist", "whitelist", "temp-ban"], required: true },
    reason:    { type: String, default: "" },
    expiresAt: { type: Date },
    requestCount: { type: Number, default: 0 },
  },
  { collection: "ip_rules", timestamps: true }
);

const shieldStatsSchema = new mongoose.Schema(
  {
    totalRequests:   { type: Number, default: 0 },
    totalBlocked:    { type: Number, default: 0 },
    totalAllowed:    { type: Number, default: 0 },
    startedAt:       { type: Date, default: Date.now },
  },
  { collection: "shield_stats" }
);

export const AttackEventModel =
  mongoose.models.AttackEvent ||
  mongoose.model("AttackEvent", attackEventSchema);

export const IpRuleModel =
  mongoose.models.IpRule ||
  mongoose.model("IpRule", ipRuleSchema);

export const ShieldStatsModel =
  mongoose.models.ShieldStats ||
  mongoose.model("ShieldStats", shieldStatsSchema);

// ─── In-memory fallback store (when MongoDB is not connected) ────────────────

type EventRecord = {
  id: string;
  ip: string;
  path: string;
  method: string;
  reason: string;
  action: "blocked" | "allowed";
  userAgent: string;
  country: string;
  timestamp: Date;
};

type IpRuleRecord = {
  id: string;
  ip: string;
  type: "blacklist" | "whitelist" | "temp-ban";
  reason: string;
  createdAt: Date;
  expiresAt?: Date;
  requestCount: number;
};

type StatsRecord = {
  totalRequests: number;
  totalBlocked: number;
  totalAllowed: number;
  startedAt: Date;
};

export const memStore: {
  events: EventRecord[];
  rules: Map<string, IpRuleRecord>;
  stats: StatsRecord;
} = {
  events: [],
  rules: new Map(),
  stats: { totalRequests: 0, totalBlocked: 0, totalAllowed: 0, startedAt: new Date() },
};
