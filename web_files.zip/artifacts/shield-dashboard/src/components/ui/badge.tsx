import * as React from "react"
import { cn } from "@/lib/utils"

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline' | 'success' | 'warning';
}

function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 font-display uppercase tracking-wider",
        {
          "border-transparent bg-primary/20 text-primary shadow-[0_0_10px_rgba(6,182,212,0.2)]": variant === "default",
          "border-transparent bg-secondary text-secondary-foreground": variant === "secondary",
          "border-transparent bg-destructive/20 text-destructive shadow-[0_0_10px_rgba(239,68,68,0.2)]": variant === "destructive",
          "border-transparent bg-success/20 text-success shadow-[0_0_10px_rgba(34,197,94,0.2)]": variant === "success",
          "border-transparent bg-warning/20 text-warning shadow-[0_0_10px_rgba(234,179,8,0.2)]": variant === "warning",
          "text-foreground": variant === "outline",
        },
        className
      )}
      {...props}
    />
  )
}

export { Badge }
