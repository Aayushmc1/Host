import { Link, useLocation } from "wouter";
import { Shield, Activity, Network, Target, Settings, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: Activity },
  { href: "/events", label: "Attack Events", icon: Target },
  { href: "/ip-manager", label: "IP Manager", icon: Network },
  { href: "/top-attackers", label: "Top Attackers", icon: Shield },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 border-r border-border/50 bg-card/30 backdrop-blur-xl h-screen sticky top-0 flex flex-col z-40 hidden md:flex">
      <div className="p-6 flex items-center gap-3">
        <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center border border-primary/50 shadow-[0_0_15px_rgba(6,182,212,0.3)] animate-radar">
          <Shield className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="font-display font-bold text-lg text-foreground leading-tight tracking-wider">
            DeployXCloud
          </h1>
          <p className="text-xs text-primary font-mono tracking-widest uppercase">Shield Active</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-4 px-2">
          Network Defense
        </div>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          
          return (
            <Link key={item.href} href={item.href}>
              <div className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer group relative overflow-hidden",
                isActive 
                  ? "text-primary bg-primary/10 border border-primary/20 shadow-[inset_0_0_20px_rgba(6,182,212,0.1)]" 
                  : "text-muted-foreground hover:text-foreground hover:bg-accent"
              )}>
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
                )}
                <Icon className={cn("h-4 w-4 transition-transform group-hover:scale-110", isActive ? "text-primary" : "text-muted-foreground")} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/50">
        <div className="bg-muted/30 rounded-lg p-4 mb-4 border border-border/50">
          <p className="text-xs text-muted-foreground font-mono mb-2">Protected Node</p>
          <p className="text-sm font-medium flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.8)]" />
            Pterodactyl Panel
          </p>
          <p className="text-xs text-muted-foreground mt-1 font-mono">Port 80</p>
        </div>
        
        <button className="flex items-center gap-3 px-3 py-2 w-full rounded-lg text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors">
          <LogOut className="h-4 w-4" />
          Disconnect
        </button>
      </div>
    </aside>
  );
}
