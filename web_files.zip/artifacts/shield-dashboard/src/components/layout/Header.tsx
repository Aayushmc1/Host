import { ShieldAlert, Bell, Menu } from "lucide-react";
import { useGetShieldStats } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";

export function Header() {
  const { data: stats } = useGetShieldStats({ query: { refetchInterval: 5000 } });

  return (
    <header className="h-16 border-b border-border/50 bg-background/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 lg:px-8">
      <div className="flex items-center gap-4">
        <button className="md:hidden text-muted-foreground hover:text-foreground">
          <Menu className="h-6 w-6" />
        </button>
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-muted/30 rounded-md border border-border/50">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
          </span>
          <span className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
            System Operational
          </span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {stats?.activeThreats ? (
          <Badge variant="destructive" className="animate-pulse hidden sm:inline-flex">
            <ShieldAlert className="w-3 h-3 mr-1" />
            {stats.activeThreats} Active Threats
          </Badge>
        ) : null}
        
        <button className="relative p-2 text-muted-foreground hover:text-foreground transition-colors rounded-full hover:bg-accent">
          <Bell className="h-5 w-5" />
          {stats?.activeThreats ? (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-destructive border border-background"></span>
          ) : null}
        </button>
        
        <div className="h-8 w-8 rounded-full bg-primary/20 border border-primary/50 flex items-center justify-center text-primary font-display font-bold">
          ADMIN
        </div>
      </div>
    </header>
  );
}
