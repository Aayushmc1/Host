import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, RefreshCw, Wifi } from "lucide-react";

type VerifyReason = "initial" | "expired" | "network";

const REASON_MESSAGES: Record<VerifyReason, { title: string; subtitle: string }> = {
  initial: {
    title:    "Verifying your connection is secure...",
    subtitle: "DeployXCloud Shield is checking your browser",
  },
  expired: {
    title:    "Session Expired — Re-verifying...",
    subtitle: "Your 15-minute session has ended. Please wait.",
  },
  network: {
    title:    "Network Change Detected — Re-verifying...",
    subtitle: "Your network has changed. Confirming your identity.",
  },
};

const STEP_TEXTS: Record<VerifyReason, string[]> = {
  initial: [
    "Establishing secure connection...",
    "Verifying browser integrity...",
    "Analyzing traffic patterns...",
    "Checking network fingerprint...",
    "Node confirmed. Granting access.",
  ],
  expired: [
    "Session token expired...",
    "Clearing old session...",
    "Performing security re-check...",
    "Generating new session token...",
    "Access re-granted.",
  ],
  network: [
    "Network change detected...",
    "Revoking previous session...",
    "Scanning new network...",
    "Verifying identity on new network...",
    "Network verified. Access granted.",
  ],
};

interface Props {
  onComplete: () => void;
  reason?: VerifyReason;
}

export function VerificationScreen({ onComplete, reason = "initial" }: Props) {
  const [progress, setProgress]   = useState(0);
  const [stepIndex, setStepIndex] = useState(0);
  const [rayId]                   = useState(() =>
    Math.random().toString(36).substring(2, 10).toUpperCase()
  );
  const startTimeRef = useRef(Date.now());
  const DURATION     = 2800; // ms

  const texts    = STEP_TEXTS[reason];
  const messages = REASON_MESSAGES[reason];

  useEffect(() => {
    startTimeRef.current = Date.now();
    setProgress(0);
    setStepIndex(0);

    const textInterval = setInterval(() => {
      setStepIndex((i) => Math.min(i + 1, texts.length - 1));
    }, DURATION / texts.length);

    const progressInterval = setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const p = Math.min((elapsed / DURATION) * 100, 100);
      setProgress(p);
      if (p >= 100) {
        clearInterval(progressInterval);
        clearInterval(textInterval);
        setStepIndex(texts.length - 1);
        setTimeout(onComplete, 350);
      }
    }, 20);

    return () => {
      clearInterval(textInterval);
      clearInterval(progressInterval);
    };
  }, [reason, onComplete, texts]);

  const ReasonIcon =
    reason === "network"  ? Wifi :
    reason === "expired"  ? RefreshCw :
    Shield;

  return (
    <motion.div
      key={reason}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.03 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Animated cyber grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(6,182,212,0.06)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,#000_10%,transparent_100%)]" />

      {/* Pulsing outer ring */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[500px] h-[500px] rounded-full border border-cyan-500/10 animate-ping" style={{ animationDuration: "3s" }} />
        <div className="absolute w-[350px] h-[350px] rounded-full border border-cyan-500/15 animate-ping" style={{ animationDuration: "2s", animationDelay: "0.5s" }} />
      </div>

      {/* Card */}
      <motion.div
        initial={{ y: 24, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.15, duration: 0.5 }}
        className="relative z-10 flex flex-col items-center max-w-md w-full px-8"
      >
        {/* Shield icon */}
        <div className="relative mb-7">
          <div className="absolute inset-0 bg-cyan-500/25 blur-[50px] rounded-full" />
          <div className="h-24 w-24 rounded-2xl bg-black border-2 border-cyan-500/50 flex items-center justify-center shadow-[0_0_40px_rgba(6,182,212,0.25)]">
            <ReasonIcon className="h-12 w-12 text-cyan-400" />
          </div>
          {/* Rotating border */}
          <div className="absolute inset-0 rounded-2xl border-2 border-transparent bg-[conic-gradient(transparent_270deg,rgba(6,182,212,0.6)_360deg)] [mask-composite:xor] [mask-image:linear-gradient(#fff,#fff),linear-gradient(#fff,#fff)] animate-spin" style={{ animationDuration: "3s" }} />
        </div>

        {/* Brand */}
        <h1 className="text-3xl font-bold text-white mb-1 tracking-widest uppercase">
          DeployXCloud <span className="text-cyan-400">Shield</span>
        </h1>

        {/* Reason subtitle */}
        <AnimatePresence mode="wait">
          <motion.p
            key={reason}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="text-xs text-cyan-500/70 font-mono tracking-widest uppercase mb-6"
          >
            {messages.subtitle}
          </motion.p>
        </AnimatePresence>

        {/* Step text with blinking cursor */}
        <div className="h-6 mb-6 flex items-center font-mono text-sm text-cyan-300">
          <AnimatePresence mode="wait">
            <motion.span
              key={stepIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {texts[stepIndex]}
            </motion.span>
          </AnimatePresence>
          <motion.span
            animate={{ opacity: [0, 1, 0] }}
            transition={{ repeat: Infinity, duration: 0.8 }}
            className="ml-1 w-2 h-4 bg-cyan-400 inline-block align-middle"
          />
        </div>

        {/* Progress bar */}
        <div className="w-full h-[3px] bg-white/10 rounded-full overflow-hidden relative mb-2">
          <motion.div
            className="absolute top-0 left-0 bottom-0 bg-cyan-400 shadow-[0_0_12px_rgba(6,182,212,1)]"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.03 }}
          />
        </div>

        {/* Meta row */}
        <div className="w-full flex justify-between text-[10px] font-mono text-white/30 uppercase tracking-widest">
          <span>Ray ID: {rayId}</span>
          <span>{Math.round(progress)}%</span>
        </div>

        {/* Session badge */}
        <div className="mt-8 flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 text-xs font-mono text-white/50">
          <span className={`w-2 h-2 rounded-full animate-pulse ${
            reason === "network" ? "bg-yellow-500" :
            reason === "expired" ? "bg-orange-500" :
            "bg-green-500"
          }`} />
          {reason === "initial" && "Performing initial security check"}
          {reason === "expired" && "Session expired after 15 minutes"}
          {reason === "network" && "New network detected — re-checking"}
        </div>
      </motion.div>
    </motion.div>
  );
}
