import { format } from "date-fns";
import { Shield, ShieldAlert, Crosshair, Globe2 } from "lucide-react";
import { useGetTopAttackers, useCreateIpRule } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatNumber } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export function TopAttackers() {
  const { data, isLoading } = useGetTopAttackers({ limit: 50 }, { query: { refetchInterval: 10000 } });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createRule = useCreateIpRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/shield/top-attackers"] });
        queryClient.invalidateQueries({ queryKey: ["/api/shield/ips"] });
        toast({ title: "IP block rule applied" });
      }
    }
  });

  const handleBlock = (ip: string) => {
    createRule.mutate({ data: { ip, type: "blacklist", reason: "Blocked from Top Attackers" } });
  };

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground flex items-center gap-2">
            <Crosshair className="w-6 h-6 text-destructive" />
            Top Attackers
          </h2>
          <p className="text-muted-foreground">Most aggressive IP addresses detected by the shield.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {data?.attackers.slice(0, 3).map((attacker, idx) => (
          <Card key={attacker.ip} className={`relative overflow-hidden ${idx === 0 ? 'border-destructive/50 shadow-[0_0_20px_rgba(239,68,68,0.15)]' : ''}`}>
            {idx === 0 && <div className="absolute top-0 right-0 w-32 h-32 bg-destructive/10 blur-3xl rounded-full" />}
            <CardContent className="p-6 relative">
              <div className="flex justify-between items-start mb-4">
                <Badge variant={idx === 0 ? "destructive" : "secondary"} className="text-lg px-3 py-1 font-bold">
                  #{idx + 1}
                </Badge>
                {attacker.status === 'blacklist' ? (
                  <Badge variant="destructive" className="animate-pulse">BANNED</Badge>
                ) : (
                  <Badge variant="outline" className="text-warning border-warning/50">ACTIVE</Badge>
                )}
              </div>
              <h3 className="text-2xl font-mono font-bold text-foreground mb-1">{attacker.ip}</h3>
              <p className="text-sm text-muted-foreground flex items-center gap-2 mb-6">
                <Globe2 className="w-4 h-4" /> {attacker.country || 'Unknown Location'}
              </p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Blocked Requests</span>
                  <span className="font-mono text-destructive font-bold">{formatNumber(attacker.blockedCount)}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-1.5">
                  <div className="bg-destructive h-1.5 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>

              {attacker.status !== 'blacklist' && (
                <Button 
                  className="w-full mt-6" 
                  variant="destructive"
                  onClick={() => handleBlock(attacker.ip)}
                  disabled={createRule.isPending}
                >
                  <ShieldAlert className="w-4 h-4 mr-2" /> Block IP
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/20 border-b border-border">
                <tr>
                  <th className="px-6 py-4 font-medium w-16">Rank</th>
                  <th className="px-6 py-4 font-medium">IP Address</th>
                  <th className="px-6 py-4 font-medium">Location</th>
                  <th className="px-6 py-4 font-medium">Blocked</th>
                  <th className="px-6 py-4 font-medium">Last Seen</th>
                  <th className="px-6 py-4 font-medium">Status</th>
                  <th className="px-6 py-4 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {data?.attackers.slice(3).map((attacker, idx) => (
                  <tr key={attacker.ip} className="hover:bg-muted/10 transition-colors">
                    <td className="px-6 py-4 font-mono text-muted-foreground font-bold">#{idx + 4}</td>
                    <td className="px-6 py-4 font-mono text-foreground font-medium">{attacker.ip}</td>
                    <td className="px-6 py-4 text-muted-foreground">{attacker.country || '-'}</td>
                    <td className="px-6 py-4 font-mono text-destructive">{formatNumber(attacker.blockedCount)}</td>
                    <td className="px-6 py-4 text-muted-foreground font-mono text-xs">
                      {format(new Date(attacker.lastSeen), 'MMM d, HH:mm:ss')}
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant={
                        attacker.status === 'blacklist' ? 'destructive' : 
                        attacker.status === 'whitelist' ? 'success' : 
                        attacker.status === 'temp-ban' ? 'warning' : 'outline'
                      }>
                        {attacker.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className={attacker.status !== 'blacklist' ? "text-destructive border-destructive/30 hover:bg-destructive hover:text-white" : ""}
                        onClick={() => handleBlock(attacker.ip)}
                        disabled={attacker.status === 'blacklist' || createRule.isPending}
                      >
                        {attacker.status === 'blacklist' ? 'Banned' : 'Ban'}
                      </Button>
                    </td>
                  </tr>
                ))}
                {isLoading && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center">
                      <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
