import { useState } from "react";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight, Filter, Search, RefreshCw } from "lucide-react";
import { useListAttackEvents, ListAttackEventsFilter } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { truncate } from "@/lib/utils";

export function AttackEvents() {
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState<ListAttackEventsFilter>("all");
  const queryClient = useQueryClient();

  const { data, isFetching, refetch } = useListAttackEvents(
    { page, limit: 15, filter }, 
    { query: { refetchInterval: 5000, keepPreviousData: true } }
  );

  const handleRefresh = () => {
    refetch();
  };

  return (
    <div className="space-y-6 max-w-[1600px] mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground">Attack Events Log</h2>
          <p className="text-muted-foreground">Detailed history of all incoming requests and blocks.</p>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          className={isFetching ? "animate-pulse opacity-80" : ""}
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      <Card>
        <div className="p-4 border-b border-border/50 flex flex-col sm:flex-row justify-between items-center gap-4 bg-muted/10">
          <div className="flex items-center gap-2 bg-background p-1 rounded-lg border border-border">
            {(['all', 'blocked', 'allowed'] as ListAttackEventsFilter[]).map((f) => (
              <button
                key={f}
                onClick={() => { setFilter(f); setPage(1); }}
                className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors capitalize ${
                  filter === f 
                    ? "bg-primary text-primary-foreground shadow-sm" 
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search IP or Path..." className="pl-9 bg-background" disabled />
          </div>
        </div>

        <CardContent className="p-0">
          <div className="overflow-x-auto min-h-[500px]">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/20 border-b border-border">
                <tr>
                  <th className="px-6 py-4 font-medium">Timestamp</th>
                  <th className="px-6 py-4 font-medium">IP Address</th>
                  <th className="px-6 py-4 font-medium">Request</th>
                  <th className="px-6 py-4 font-medium">Reason</th>
                  <th className="px-6 py-4 font-medium">User Agent</th>
                  <th className="px-6 py-4 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {data?.events.map((event) => (
                  <tr key={event.id} className="hover:bg-muted/10 transition-colors">
                    <td className="px-6 py-3 font-mono text-muted-foreground whitespace-nowrap">
                      {format(new Date(event.timestamp), 'MMM d, HH:mm:ss')}
                    </td>
                    <td className="px-6 py-3 font-mono text-foreground flex items-center gap-2">
                      {event.country && <span className="text-lg leading-none" title={event.country}>{/* Country emoji if needed, or abbreviation */}{event.country}</span>}
                      {event.ip}
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <span className={`font-mono text-xs px-1.5 py-0.5 rounded ${
                          event.method === 'GET' ? 'bg-blue-500/10 text-blue-400' :
                          event.method === 'POST' ? 'bg-green-500/10 text-green-400' :
                          'bg-orange-500/10 text-orange-400'
                        }`}>
                          {event.method}
                        </span>
                        <span className="text-muted-foreground font-mono text-xs">{truncate(event.path, 25)}</span>
                      </div>
                    </td>
                    <td className="px-6 py-3 text-muted-foreground text-xs">{event.reason || '-'}</td>
                    <td className="px-6 py-3 text-muted-foreground text-xs font-mono" title={event.userAgent}>
                      {truncate(event.userAgent || '-', 30)}
                    </td>
                    <td className="px-6 py-3 text-right">
                      <Badge variant={event.action === 'blocked' ? 'destructive' : 'success'}>
                        {event.action}
                      </Badge>
                    </td>
                  </tr>
                ))}
                {data?.events.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                      <Filter className="w-8 h-8 mx-auto mb-3 opacity-20" />
                      <p>No events found for the selected filter.</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="p-4 border-t border-border/50 flex items-center justify-between bg-muted/5">
            <p className="text-sm text-muted-foreground">
              Showing <span className="font-medium text-foreground">{data?.events.length || 0}</span> of <span className="font-medium text-foreground">{data?.total || 0}</span> events
            </p>
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
              >
                <ChevronLeft className="w-4 h-4 mr-1" /> Prev
              </Button>
              <div className="text-sm font-medium px-4">
                Page {page} of {data?.totalPages || 1}
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setPage(p => p + 1)}
                disabled={page >= (data?.totalPages || 1)}
              >
                Next <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
