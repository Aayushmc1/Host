import { motion } from "framer-motion";
import { Activity, Shield, ShieldAlert, ShieldCheck, ActivitySquare, Ban, Globe2, ArrowRight } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { Link } from "wouter";
import { format } from "date-fns";

import { useGetShieldStats, useGetAttackChart, useListAttackEvents, useGetTopAttackers, useCreateIpRule } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatNumber, truncate } from "@/lib/utils";

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
};

export function Dashboard() {
  const { data: stats } = useGetShieldStats({ query: { refetchInterval: 5000 } });
  const { data: chartData } = useGetAttackChart({ query: { refetchInterval: 10000 } });
  const { data: recentEvents } = useListAttackEvents({ limit: 5, filter: "all" }, { query: { refetchInterval: 3000 } });
  const { data: topAttackers } = useGetTopAttackers({ limit: 5 }, { query: { refetchInterval: 10000 } });
  const createRule = useCreateIpRule();

  const handleBlockIp = (ip: string) => {
    createRule.mutate({ data: { ip, type: "blacklist", reason: "Quick block from Dashboard" } });
  };

  if (!stats || !chartData) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="space-y-6 max-w-[1600px] mx-auto"
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground">Overview</h2>
          <p className="text-muted-foreground">Real-time network traffic and threat analysis.</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={stats.protectionStatus === 'active' ? 'success' : 'warning'} className="px-3 py-1 text-sm">
            {stats.protectionStatus === 'active' && <span className="w-2 h-2 rounded-full bg-current animate-pulse mr-2" />}
            {stats.protectionStatus.toUpperCase()}
          </Badge>
          <div className="text-sm font-mono text-muted-foreground px-3 py-1 bg-card border border-border rounded-md">
            Uptime: {Math.floor(stats.uptime / 3600)}h {Math.floor((stats.uptime % 3600) / 60)}m
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div variants={itemVariants}>
          <Card className="bg-gradient-to-br from-card to-card/50">
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Total Requests</p>
                  <p className="text-3xl font-mono font-bold">{formatNumber(stats.totalRequests)}</p>
                </div>
                <div className="p-3 bg-primary/10 rounded-lg text-primary">
                  <Globe2 className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm font-mono text-primary">
                <Activity className="w-4 h-4 mr-1" />
                {stats.requestsPerMinute} / min
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="bg-gradient-to-br from-destructive/10 to-card/50 border-destructive/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-destructive/10 blur-3xl rounded-full" />
            <CardContent className="p-6 relative">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Threats Blocked</p>
                  <p className="text-3xl font-mono font-bold text-destructive">{formatNumber(stats.totalBlocked)}</p>
                </div>
                <div className="p-3 bg-destructive/10 rounded-lg text-destructive">
                  <ShieldAlert className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm font-mono text-destructive">
                <Ban className="w-4 h-4 mr-1" />
                {stats.blockedPerMinute} / min
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Allowed Traffic</p>
                  <p className="text-3xl font-mono font-bold text-success">{formatNumber(stats.totalAllowed)}</p>
                </div>
                <div className="p-3 bg-success/10 rounded-lg text-success">
                  <ShieldCheck className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 text-sm text-muted-foreground">
                {(stats.totalAllowed / Math.max(1, stats.totalRequests) * 100).toFixed(1)}% pass rate
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className={stats.activeThreats > 0 ? "border-warning bg-warning/5" : ""}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Active Threats</p>
                  <p className="text-3xl font-mono font-bold text-warning">{formatNumber(stats.activeThreats)}</p>
                </div>
                <div className="p-3 bg-warning/10 rounded-lg text-warning">
                  <ActivitySquare className="w-5 h-5" />
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <Badge variant="outline" className="font-mono">{stats.tempBannedIps} temp-bans</Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <motion.div variants={itemVariants} className="lg:col-span-2">
          <Card className="h-[400px] flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle>Attack Timeline (24h)</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 min-h-0 pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData.points} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorBlocked" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis 
                    dataKey="time" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    tickFormatter={(val) => format(new Date(val), 'HH:mm')}
                    tickMargin={10}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12}
                    tickFormatter={(val) => val >= 1000 ? `${(val/1000).toFixed(1)}k` : val}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    labelStyle={{ color: 'hsl(var(--muted-foreground))' }}
                    labelFormatter={(label) => format(new Date(label), 'MMM d, HH:mm:ss')}
                  />
                  <Area type="monotone" dataKey="requests" name="Total Requests" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorRequests)" />
                  <Area type="monotone" dataKey="blocked" name="Blocked" stroke="hsl(var(--destructive))" fillOpacity={1} fill="url(#colorBlocked)" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Top Attackers Mini */}
        <motion.div variants={itemVariants}>
          <Card className="h-[400px] flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Top Attackers</CardTitle>
              <Link href="/top-attackers">
                <Button variant="ghost-primary" size="icon" className="h-8 w-8">
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto pr-2">
              {topAttackers?.attackers.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-2">
                  <ShieldCheck className="h-8 w-8 text-success/50" />
                  <p>No active attackers</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {topAttackers?.attackers.map((attacker, i) => (
                    <div key={attacker.ip} className="flex items-center justify-between p-3 rounded-lg border border-border/50 bg-muted/20 hover:bg-muted/40 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="text-xs font-bold text-muted-foreground w-4">{i + 1}</div>
                        <div>
                          <p className="font-mono text-sm text-foreground">{attacker.ip}</p>
                          <p className="text-xs text-destructive font-medium">{formatNumber(attacker.blockedCount)} blocks</p>
                        </div>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="h-7 text-xs border-destructive/30 text-destructive hover:bg-destructive hover:text-white"
                        onClick={() => handleBlockIp(attacker.ip)}
                        disabled={attacker.status === 'blacklist'}
                      >
                        {attacker.status === 'blacklist' ? 'Banned' : 'Ban'}
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Events Table */}
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Traffic Events</CardTitle>
            <Link href="/events">
              <Button variant="outline" size="sm">View All Logs</Button>
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-muted-foreground uppercase bg-muted/20 border-b border-border">
                  <tr>
                    <th className="px-6 py-3 font-medium">Time</th>
                    <th className="px-6 py-3 font-medium">IP Address</th>
                    <th className="px-6 py-3 font-medium">Request</th>
                    <th className="px-6 py-3 font-medium">Reason</th>
                    <th className="px-6 py-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {recentEvents?.events.map((event) => (
                    <tr key={event.id} className="hover:bg-muted/10 transition-colors group">
                      <td className="px-6 py-4 font-mono text-muted-foreground whitespace-nowrap">
                        {format(new Date(event.timestamp), 'HH:mm:ss')}
                      </td>
                      <td className="px-6 py-4 font-mono text-foreground">{event.ip}</td>
                      <td className="px-6 py-4">
                        <span className="font-mono text-primary mr-2">{event.method}</span>
                        <span className="text-muted-foreground">{truncate(event.path, 30)}</span>
                      </td>
                      <td className="px-6 py-4 text-muted-foreground">{truncate(event.reason, 40) || '-'}</td>
                      <td className="px-6 py-4">
                        <Badge variant={event.action === 'blocked' ? 'destructive' : 'success'}>
                          {event.action}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                  {(!recentEvents || recentEvents.events.length === 0) && (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">
                        No recent events recorded.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
