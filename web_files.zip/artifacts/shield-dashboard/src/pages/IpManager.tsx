import { useState } from "react";
import { format } from "date-fns";
import { Plus, Trash2, Search, ShieldBan, ShieldCheck, Clock } from "lucide-react";
import { useListIpRules, useCreateIpRule, useDeleteIpRule, IpRuleType } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export function IpManager() {
  const [activeTab, setActiveTab] = useState<IpRuleType>("blacklist");
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newIp, setNewIp] = useState("");
  const [newReason, setNewReason] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data, isLoading } = useListIpRules();
  const createRule = useCreateIpRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/shield/ips"] });
        setIsAddOpen(false);
        setNewIp("");
        setNewReason("");
        toast({ title: "Rule added successfully", variant: "default" });
      },
      onError: (err: any) => {
        toast({ title: "Failed to add rule", description: err.message, variant: "destructive" });
      }
    }
  });
  const deleteRule = useDeleteIpRule({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/shield/ips"] });
        toast({ title: "Rule removed successfully" });
      }
    }
  });

  const filteredRules = data?.rules.filter(r => r.type === activeTab) || [];

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIp) return;
    createRule.mutate({ 
      data: { 
        ip: newIp, 
        type: activeTab === 'temp-ban' ? 'blacklist' : activeTab, 
        reason: newReason 
      } 
    });
  };

  return (
    <div className="space-y-6 max-w-[1200px] mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground">IP Manager</h2>
          <p className="text-muted-foreground">Manage access control lists and view temporary bans.</p>
        </div>
        <Button onClick={() => setIsAddOpen(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Rule
        </Button>
      </div>

      <Card>
        <div className="flex border-b border-border/50 bg-muted/10 overflow-x-auto">
          <button
            onClick={() => setActiveTab("blacklist")}
            className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "blacklist" ? "border-destructive text-destructive" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <ShieldBan className="w-4 h-4" /> Blacklist
          </button>
          <button
            onClick={() => setActiveTab("whitelist")}
            className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "whitelist" ? "border-success text-success" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <ShieldCheck className="w-4 h-4" /> Whitelist
          </button>
          <button
            onClick={() => setActiveTab("temp-ban")}
            className={`flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "temp-ban" ? "border-warning text-warning" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Clock className="w-4 h-4" /> Temp Banned
          </button>
        </div>

        <CardContent className="p-0">
          <div className="overflow-x-auto min-h-[400px]">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/5 border-b border-border/50">
                <tr>
                  <th className="px-6 py-4 font-medium">IP Address</th>
                  <th className="px-6 py-4 font-medium">Reason</th>
                  <th className="px-6 py-4 font-medium">Created</th>
                  {activeTab === 'temp-ban' && <th className="px-6 py-4 font-medium">Expires</th>}
                  <th className="px-6 py-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {filteredRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-muted/10 transition-colors group">
                    <td className="px-6 py-4 font-mono text-foreground font-medium">{rule.ip}</td>
                    <td className="px-6 py-4 text-muted-foreground">{rule.reason || 'Manual entry'}</td>
                    <td className="px-6 py-4 text-muted-foreground font-mono text-xs">
                      {format(new Date(rule.createdAt), 'MMM d, yyyy HH:mm')}
                    </td>
                    {activeTab === 'temp-ban' && (
                      <td className="px-6 py-4 text-warning font-mono text-xs">
                        {rule.expiresAt ? format(new Date(rule.expiresAt), 'MMM d, yyyy HH:mm') : '-'}
                      </td>
                    )}
                    <td className="px-6 py-4 text-right">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => {
                          if (confirm(`Remove ${rule.ip} from ${activeTab}?`)) {
                            deleteRule.mutate({ ip: rule.ip });
                          }
                        }}
                        disabled={deleteRule.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
                {!isLoading && filteredRules.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-16 text-center text-muted-foreground">
                      No IPs found in {activeTab}.
                    </td>
                  </tr>
                )}
                {isLoading && (
                  <tr>
                    <td colSpan={5} className="px-6 py-16 text-center">
                      <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog 
        isOpen={isAddOpen} 
        onClose={() => setIsAddOpen(false)}
        title={`Add to ${activeTab === 'temp-ban' ? 'Blacklist' : activeTab.charAt(0).toUpperCase() + activeTab.slice(1)}`}
        description="Enter the IP address and an optional reason."
      >
        <form onSubmit={handleAddSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">IP Address</label>
            <Input 
              placeholder="e.g., 192.168.1.1" 
              value={newIp} 
              onChange={e => setNewIp(e.target.value)}
              required
              pattern="^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$"
              title="Valid IPv4 address"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Reason (Optional)</label>
            <Input 
              placeholder="Why is this IP being added?" 
              value={newReason} 
              onChange={e => setNewReason(e.target.value)}
              className="font-sans"
            />
          </div>
          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={createRule.isPending}>
              {createRule.isPending ? "Adding..." : "Add IP"}
            </Button>
          </div>
        </form>
      </Dialog>
    </div>
  );
}
