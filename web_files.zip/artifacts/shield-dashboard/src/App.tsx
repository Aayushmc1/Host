import { useState, useEffect, useCallback, useRef } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import { VerificationScreen } from "@/pages/VerificationScreen";
import { MainLayout } from "@/components/layout/MainLayout";
import { Dashboard } from "@/pages/Dashboard";
import { AttackEvents } from "@/pages/AttackEvents";
import { IpManager } from "@/pages/IpManager";
import { TopAttackers } from "@/pages/TopAttackers";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: false },
  },
});

// ─── Verification constants ────────────────────────────────────────────────
const VERIFY_DURATION_MS = 15 * 60 * 1000; // 15 minutes
const STORAGE_KEY_VERIFIED_AT = "dxc_verified_at";
const STORAGE_KEY_NETWORK_IP  = "dxc_network_ip";

async function fetchMyIp(): Promise<string> {
  try {
    const base = import.meta.env.BASE_URL || "/";
    const res = await fetch(`${base}api/my-ip`.replace("//", "/"), { cache: "no-store" });
    if (!res.ok) return "";
    const data = await res.json() as { ip?: string };
    return data.ip ?? "";
  } catch {
    return "";
  }
}

function needsVerification(currentIp: string): boolean {
  const verifiedAt = localStorage.getItem(STORAGE_KEY_VERIFIED_AT);
  const storedIp   = localStorage.getItem(STORAGE_KEY_NETWORK_IP);

  if (!verifiedAt) return true;

  const elapsed = Date.now() - Number(verifiedAt);
  if (elapsed >= VERIFY_DURATION_MS) return true;

  // If we have both IPs and they differ, force re-verify
  if (currentIp && storedIp && currentIp !== storedIp) return true;

  return false;
}

function markVerified(ip: string) {
  localStorage.setItem(STORAGE_KEY_VERIFIED_AT, String(Date.now()));
  if (ip) localStorage.setItem(STORAGE_KEY_NETWORK_IP, ip);
}

// ─── Router ────────────────────────────────────────────────────────────────
function Router() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/"              component={Dashboard}     />
        <Route path="/events"        component={AttackEvents}  />
        <Route path="/ip-manager"    component={IpManager}     />
        <Route path="/top-attackers" component={TopAttackers}  />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

// ─── App ───────────────────────────────────────────────────────────────────
function App() {
  const [verified, setVerified]   = useState(false);
  const [checking, setChecking]   = useState(true); // checking session on first load
  const [reason, setReason]       = useState<"initial" | "expired" | "network">("initial");
  const currentIpRef              = useRef("");
  const timerRef                  = useRef<ReturnType<typeof setTimeout> | null>(null);

  // On mount: fetch IP and decide whether to show verification
  useEffect(() => {
    (async () => {
      const ip = await fetchMyIp();
      currentIpRef.current = ip;

      if (needsVerification(ip)) {
        const storedIp = localStorage.getItem(STORAGE_KEY_NETWORK_IP);
        const verifiedAt = localStorage.getItem(STORAGE_KEY_VERIFIED_AT);
        if (verifiedAt && ip && storedIp && ip !== storedIp) {
          setReason("network");
        } else if (verifiedAt && Number(verifiedAt) > 0) {
          setReason("expired");
        } else {
          setReason("initial");
        }
        setChecking(false);
        setVerified(false);
      } else {
        setVerified(true);
        setChecking(false);
        scheduleRecheck();
      }
    })();
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Schedule the next forced re-verification
  const scheduleRecheck = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    const verifiedAt = Number(localStorage.getItem(STORAGE_KEY_VERIFIED_AT) ?? "0");
    const remaining  = VERIFY_DURATION_MS - (Date.now() - verifiedAt);
    const delay      = Math.max(remaining, 1000);
    timerRef.current = setTimeout(() => {
      setReason("expired");
      setVerified(false);
    }, delay);
  }, []);

  const handleVerified = useCallback(() => {
    markVerified(currentIpRef.current);
    setVerified(true);
    scheduleRecheck();
  }, [scheduleRecheck]);

  // Poll for network change every 60 seconds while dashboard is open
  useEffect(() => {
    if (!verified) return;
    const interval = setInterval(async () => {
      const ip = await fetchMyIp();
      if (!ip) return;
      currentIpRef.current = ip;
      const storedIp = localStorage.getItem(STORAGE_KEY_NETWORK_IP);
      if (storedIp && ip !== storedIp) {
        setReason("network");
        setVerified(false);
      }
    }, 60_000);
    return () => clearInterval(interval);
  }, [verified]);

  if (checking) return null; // invisible while we check session

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {!verified ? (
          <VerificationScreen onComplete={handleVerified} reason={reason} />
        ) : (
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
        )}
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
